/*
Christian asano
Main javascript page

Date: 1/29/2024
Purpose: To test console log comment pages
*/

// I had a hard time at first I believe I did this corrrect.
console.log("JavaScript is crazy hard!");
console.log("My favorite websites would be in this order... https://www.lyricallemonade.com/ , https://www.flightclub.com/ , and https://soundcloud.com/casano2");
console.log("My favorite 3 video games are Madden 18, Fortnite, and Black Opps 2 ");
console.log("My 3 favorite artists are Juice wrld who made a huge impact to young black artists, Lil Uzi vert because he was the reason kids listen to rap since 2016, and Future who has been around for 20 years and makes hits that are relatable to young adults trying to grind life.");

